import 'package:flutter/material.dart';
import 'package:flutter_grocery_shopping/SizeConfig.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      home: Dairy(),
    );
  }
}

class Dairy extends StatefulWidget {
  Dairy({Key key, this.title}) : super(key: key);


  final String title;

  @override
  _DairyState createState() => _DairyState();
}

class _DairyState extends State<Dairy> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
              child: Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Column(
                      children: <Widget>[
                        _buildDairyCard("Milk (Tetra Pack)", "assets/milk.png","₹60", 0xffF7DFB9, 0XffFAF0DA),
                        SizedBox(height: 2 * SizeConfig.heightMultiplier,),
                        GestureDetector(
                          onTap: (){
                          },
                        ),
                        SizedBox(height: 2 * SizeConfig.heightMultiplier,),
                      ],
                    ),
                    Spacer(),

                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

_buildDairyCard(String name, String asset, String rate, int color, int color2) {
  return Container(
    width: 42.5 * SizeConfig.widthMultiplier,
    decoration: BoxDecoration(
      color: Color(color),
      borderRadius: BorderRadius.circular(20.0),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Align(
          alignment: Alignment.topRight,
          child: Container(
            decoration: BoxDecoration(
                color: Color(color2),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20.0),
                  topRight: Radius.circular(20.0),
                )
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.add, color: Colors.grey,),
            ),
          ),
        ),
        Center(
          child: Image.asset(
            asset,
            fit: BoxFit.contain,
            height: 30 * SizeConfig.imageSizeMultiplier,
            width: 30 * SizeConfig.imageSizeMultiplier,),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10.0, top: 10.0),
          child: Text(name, style: TextStyle(
              fontFamily: 'OpenSans-Bold',
              fontWeight: FontWeight.bold,
              fontSize: 2.5 * SizeConfig.textMultiplier
          ),),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10.0, top: 10.0),
          child: Text("Vadodra Super Store", style: TextStyle(
              fontFamily: 'OpenSans-Bold',
              fontWeight: FontWeight.bold,
              fontSize: 1.5 * SizeConfig.textMultiplier
          ),),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 10.0),
          child: Row(
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(rate, style: TextStyle(
                      fontFamily: 'OpenSans',
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 2.5 * SizeConfig.textMultiplier
                  ),),
                  Text("Per Litre", style: TextStyle(
                      fontFamily: 'OpenSans',
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 1.3 * SizeConfig.textMultiplier
                  ),),
                ],
              ),
              Spacer(),
              Text("View Prices", style: TextStyle(
                  fontFamily: 'OpenSans',
                  color: Colors.black87,
                  fontWeight: FontWeight.bold,
                  fontSize: 1.3 * SizeConfig.textMultiplier
              ),),
            ],
          ),
        ),
        SizedBox(height: 2 * SizeConfig.heightMultiplier,)
      ],
    ),
  );
}


